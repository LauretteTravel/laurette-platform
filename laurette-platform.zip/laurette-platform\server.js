import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { extname, join, normalize, resolve } from 'node:path';
import { randomBytes } from 'node:crypto';
import { fileURLToPath } from 'node:url';

import { openDb, seedDatabase, loadSeed, one, q } from './lib/db.js';
import { hashPassword, sessionUser, purgeExpiredSessions } from './lib/auth.js';
import { HttpError, createRouter, json, html, text, redirect, parseCookies, securityHeaders, clientIp, RateLimiter } from './lib/http.js';
import { artSvg, ART_KEYS } from './lib/art.js';
import { ASSET_V } from './lib/views/layout.js';
import { homePage, programsPage, programPage, umrahPage, hotelsPage, getSettings } from './lib/views/public.js';
import { flightsPage, visaPage, consultPage, destinationsPage, destinationPage, guidePage, articlePage, faqPage, trackPage, aboutPage, privacyPage, newsPage, offlinePage, offersPage } from './lib/views/public2.js';
import * as API from './lib/api.js';
import { COOKIE } from './lib/api.js';

const HERE = fileURLToPath(new URL('.', import.meta.url));
const PUBLIC_DIR = join(HERE, 'public');
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
};

export function createApp(options = {}) {
  const dbFile = options.dbFile || process.env.DB_FILE || join(HERE, 'data', 'laurette.db');
  const baseUrl = (options.baseUrl || process.env.BASE_URL || 'http://localhost:3000').replace(/\/$/, '');
  const db = openDb(dbFile);
  const seed = loadSeed(options.seedFile || join(HERE, 'data', 'seed.json'));
  const seedResult = seedDatabase(db, seed, hashPassword);
  purgeExpiredSessions(db);

  const limiter = new RateLimiter();
  const router = createRouter();
  const startedAt = Date.now();

  /* ---------------- pages ---------------- */
  const page = (fn, opts = {}) => (ctx) => {
    const body = fn(ctx, ctx.params?.slug);
    if (body === null) {
      const settings = getSettings(db);
      return html(ctx.res, 404, offlinePage({ settings, nonce: ctx.nonce, baseUrl }), { ...securityHeaders(ctx.nonce, ctx.secure) });
    }
    return html(ctx.res, 200, body, { ...securityHeaders(ctx.nonce, ctx.secure) });
  };

  router.get('/', page(homePage));
  router.get('/programs', page(programsPage));
  router.get('/offers', page(offersPage));
  router.get('/programs/:slug', page(programPage));
  router.get('/umrah', page(umrahPage));
  router.get('/flights', page(flightsPage));
  router.get('/hotels', page(hotelsPage));
  router.get('/visa', page(visaPage));
  router.get('/consult', page(consultPage));
  router.get('/destinations', page(destinationsPage));
  router.get('/destinations/:slug', page(destinationPage));
  router.get('/guide', page(guidePage));
  router.get('/guide/:slug', page(articlePage));
  router.get('/faq', page(faqPage));
  router.get('/track', page(trackPage));
  router.get('/about', page(aboutPage));
  router.get('/privacy', page(privacyPage));
  router.get('/news', page(newsPage));

  /* ---------------- admin shell ---------------- */
  router.get('/admin', (ctx) => html(ctx.res, 200, adminShell(ctx), {
    ...securityHeaders(ctx.nonce, ctx.secure), 'cache-control': 'no-store',
  }));
  router.get('/admin/:rest*', (ctx) => html(ctx.res, 200, adminShell(ctx), {
    ...securityHeaders(ctx.nonce, ctx.secure), 'cache-control': 'no-store',
  }));

  /* ---------------- api ---------------- */
  const POST_LIMITS = {
    '/api/requests': { max: 20, window: 3600_000 },
    '/api/track': { max: 30, window: 3600_000 },
    '/api/assistant': { max: 80, window: 3600_000 },
    '/api/recommend': { max: 60, window: 3600_000 },
    '/api/auth/login': { max: 12, window: 600_000 },
  };

  const api = (handler, { auth = false, action = null, limit = null } = {}) => async (ctx) => {
    if (limit) {
      const rule = POST_LIMITS[limit];
      if (rule) {
        const hit = limiter.hit(`${limit}|${ctx.ip}`, rule.max, rule.window);
        if (!hit.allowed) {
          ctx.res.setHeader('retry-after', String(hit.retryAfter));
          return json(ctx.res, 429, { ok: false, message: 'عدد المحاولات كبير. حاول لاحقًا.' });
        }
      }
    }
    if (auth && !ctx.user) return json(ctx.res, 401, { ok: false, message: 'يلزم تسجيل الدخول' });
    if (action && !ctx.user) return json(ctx.res, 401, { ok: false, message: 'يلزم تسجيل الدخول' });
    return handler(ctx);
  };

  router.post('/api/auth/login', api(API.login, { limit: '/api/auth/login' }));
  router.post('/api/auth/logout', api(API.logout));
  router.get('/api/auth/me', API.me);
  router.post('/api/auth/change-password', api(API.changePassword, { auth: true }));

  router.post('/api/requests', api(API.createRequestApi, { limit: '/api/requests' }));
  router.post('/api/track', api(API.trackRequest, { limit: '/api/track' }));
  router.get('/api/programs', API.listProgramsApi);
  router.get('/api/programs/:slug', API.getProgramApi);
  router.post('/api/recommend', api(API.recommendApi, { limit: '/api/recommend' }));
  router.post('/api/assistant', api(API.assistantApi, { limit: '/api/assistant' }));

  router.get('/api/admin/overview', api(API.overview, { action: 'overview:read' }));
  router.get('/api/admin/requests', api(API.listRequests, { action: 'requests:read' }));
  router.get('/api/admin/requests/:id', api(API.getRequest, { action: 'requests:read' }));
  router.patch('/api/admin/requests/:id', api(API.updateRequest, { action: 'requests:write' }));
  router.get('/api/admin/customers', api(API.listCustomers, { action: 'customers:read' }));
  router.get('/api/admin/customers/:id', api(API.getCustomer, { action: 'customers:read' }));
  router.patch('/api/admin/customers/:id', api(API.updateCustomer, { action: 'customers:write' }));

  for (const resource of ['programs', 'offers', 'news', 'articles', 'faq', 'visa', 'kb', 'destinations', 'reviews']) {
    router.get(`/api/admin/${resource}`, (ctx) => API.listResource(ctx, resource));
    router.post(`/api/admin/${resource}`, (ctx) => API.createResource(ctx, resource));
    router.patch(`/api/admin/${resource}/:id`, (ctx) => API.updateResource(ctx, resource));
    router.delete(`/api/admin/${resource}/:id`, (ctx) => API.deleteResource(ctx, resource));
  }

  router.get('/api/admin/users', api(API.listUsers, { action: 'users:write' }));
  router.post('/api/admin/users', api(API.createUser, { action: 'users:write' }));
  router.patch('/api/admin/users/:id', api(API.updateUser, { action: 'users:write' }));
  router.get('/api/admin/audit', api(API.auditLog, { action: 'audit:read' }));
  router.get('/api/admin/media', api(API.listMedia, { action: 'content:write' }));
  router.get('/api/admin/settings', api(API.getSettings, { action: 'settings:write' }));
  router.patch('/api/admin/settings', api(API.updateSettings, { action: 'settings:write' }));
  router.get('/api/admin/assistant-log', api(API.assistantLog, { action: 'overview:read' }));

  /* ---------------- generated assets & seo ---------------- */
  router.get('/art/:file', (ctx) => {
    const match = /^([a-z]+)\.svg$/.exec(ctx.params.file || '');
    const key = match && ART_KEYS.includes(match[1]) ? match[1] : 'haram';
    const variant = Number(ctx.query.v || 0) % 4;
    const svg = artSvg(key, variant);
    ctx.res.writeHead(200, {
      'content-type': 'image/svg+xml; charset=utf-8',
      'content-length': Buffer.byteLength(svg),
      'cache-control': 'public, max-age=604800, immutable',
    });
    ctx.res.end(svg);
  });

  router.get('/sitemap.xml', (ctx) => {
    const urls = ['/', '/programs', '/offers', '/umrah', '/flights', '/hotels', '/visa', '/consult', '/destinations', '/guide', '/faq', '/about', '/news'];
    const programs = q(db, "SELECT slug, updated_at FROM programs WHERE status IN ('published','sold_out')");
    const destinations = q(db, 'SELECT slug FROM destinations WHERE published = 1');
    const articles = q(db, "SELECT slug, updated_at FROM articles WHERE status = 'published'");
    const entries = [
      ...urls.map((u) => ({ loc: `${baseUrl}${u}`, priority: u === '/' ? '1.0' : '0.8' })),
      ...programs.map((p) => ({ loc: `${baseUrl}/programs/${p.slug}`, priority: '0.7', lastmod: String(p.updated_at || '').slice(0, 10) })),
      ...destinations.map((d) => ({ loc: `${baseUrl}/destinations/${d.slug}`, priority: '0.6' })),
      ...articles.map((a) => ({ loc: `${baseUrl}/guide/${a.slug}`, priority: '0.6', lastmod: String(a.updated_at || '').slice(0, 10) })),
    ];
    const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${entries.map((e) => `  <url><loc>${e.loc}</loc>${e.lastmod ? `<lastmod>${e.lastmod}</lastmod>` : ''}<priority>${e.priority}</priority></url>`).join('\n')}\n</urlset>`;
    text(ctx.res, 200, xml, 'application/xml; charset=utf-8', { 'cache-control': 'public, max-age=3600' });
  });

  router.get('/robots.txt', (ctx) => {
    const body = `User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /track\nDisallow: /api/\n\nSitemap: ${baseUrl}/sitemap.xml\n`;
    text(ctx.res, 200, body, 'text/plain; charset=utf-8', { 'cache-control': 'public, max-age=3600' });
  });

  router.get('/site.webmanifest', (ctx) => {
    const manifest = {
      name: 'لوريت للسياحة والسفر',
      short_name: 'لوريت',
      start_url: '/',
      display: 'standalone',
      background_color: '#FFFFFF',
      theme_color: '#0B2A43',
      lang: 'ar',
      dir: 'rtl',
      icons: [{ src: '/art/haram.svg?v=0', sizes: 'any', type: 'image/svg+xml', purpose: 'any' }],
    };
    text(ctx.res, 200, JSON.stringify(manifest), 'application/manifest+json; charset=utf-8');
  });

  router.get('/health', (ctx) => json(ctx.res, 200, {
    ok: true, uptimeSeconds: Math.round((Date.now() - startedAt) / 1000), seeded: seedResult.seeded, programs: one(db, 'SELECT COUNT(*) n FROM programs').n,
  }));

  /* ---------------- static ---------------- */
  async function serveStatic(req, res, pathname) {
    const rel = normalize(pathname).replace(/^([/\\])+/, '');
    const file = resolve(PUBLIC_DIR, rel);
    if (!file.startsWith(resolve(PUBLIC_DIR))) return false;
    try {
      const data = await readFile(file);
      const ext = extname(file).toLowerCase();
      const isHtml = ext === '.html';
      const revalidate = isHtml || ext === '.js' || ext === '.css';
      res.writeHead(200, {
        'content-type': MIME[ext] || 'application/octet-stream',
        'content-length': data.length,
        'cache-control': revalidate ? 'no-cache' : 'public, max-age=604800',
        'x-content-type-options': 'nosniff',
      });
      res.end(req.method === 'HEAD' ? undefined : data);
      return true;
    } catch {
      return false;
    }
  }

  async function handle(req, res) {
    const started = Date.now();
    const url = new URL(req.url, baseUrl);
    const pathname = url.pathname;
    const nonce = randomBytes(16).toString('base64');
    const secure = req.headers['x-forwarded-proto'] === 'https' || baseUrl.startsWith('https://');
    const cookies = parseCookies(req);
    const token = cookies[COOKIE] || null;
    const user = sessionUser(db, token);
    const ctx = {
      req, res, db, params: {}, query: Object.fromEntries(url.searchParams.entries()),
      user, token, nonce, baseUrl, secure, ip: clientIp(req),
      settings: getSettings(db),
    };

    res.setHeader('x-request-id', randomBytes(6).toString('hex'));
    for (const [headerName, headerValue] of Object.entries(securityHeaders(nonce, secure))) {
      res.setHeader(headerName, headerValue);
    }

    if (req.method === 'GET' || req.method === 'HEAD') {
      if (pathname.startsWith('/assets/') || pathname.startsWith('/media/')) {
        const served = await serveStatic(req, res, pathname);
        if (served) return;
        return text(res, 404, 'Not found');
      }
    }

    if (pathname.length > 1 && pathname.endsWith('/')) {
      return redirect(res, pathname.replace(/\/+$/, '') + (url.search || ''), 301);
    }

    if (pathname.startsWith('/api/')) {
      if (!['GET', 'HEAD'].includes(req.method)) {
        const requestedWith = req.headers['x-requested-with'];
        const origin = req.headers.origin;
        const sameOrigin = !origin || origin === baseUrl || (origin && req.headers.host && origin.endsWith(req.headers.host));
        if (requestedWith !== 'fetch' && !sameOrigin) {
          return json(res, 403, { ok: false, message: 'طلب غير مسموح' });
        }
      }
      const match = router.match(req.method, pathname);
      if (!match) return json(res, 404, { ok: false, message: 'المسار غير موجود' });
      ctx.params = match.params;
      try {
        const result = match.route.handler(ctx);
        if (result && typeof result.then === 'function') await result;
        return;
      } catch (err) {
        return handleError(ctx, err);
      }
    }

    if (!['GET', 'HEAD'].includes(req.method)) return text(res, 405, 'Method not allowed');

    const match = router.match('GET', pathname);
    if (!match) {
      const settings = getSettings(db);
      return html(res, 404, offlinePage({ settings, nonce, baseUrl }), { ...securityHeaders(nonce, secure) });
    }
    ctx.params = match.params;
    try {
      await match.route.handler(ctx);
    } catch (err) {
      handleError(ctx, err);
    } finally {
      if (!res.writableEnded) {
        res.end();
      }
    }
  }

  function handleError(ctx, err) {
    const isApi = ctx.req.url.startsWith('/api/');
    if (!(err instanceof HttpError)) console.error('[error]', err);
    if (isApi) {
      return json(ctx.res, err.status || 500, {
        ok: false,
        message: err.status ? err.message : 'حدث خطأ غير متوقع. حاول لاحقًا.',
        ...(err.details ? { errors: err.details } : {}),
      });
    }
    const settings = getSettings(db);
    return html(ctx.res, err.status || 500, offlinePage({ settings, nonce: ctx.nonce, baseUrl }), { ...securityHeaders(ctx.nonce, ctx.secure) });
  }

  const server = http.createServer((req, res) => {
    res.on('finish', () => {
      if (process.env.LOG_REQUESTS === '1') console.log(`${req.method} ${req.url} ${res.statusCode}`);
    });
    handle(req, res).catch((err) => {
      console.error('[fatal]', err);
      if (!res.headersSent) res.writeHead(500, { 'content-type': 'text/plain; charset=utf-8' });
      res.end('Internal error');
    });
  });

  return {
    server, db, baseUrl, limiter,
    listen(port = 3000, host = '127.0.0.1') {
      return new Promise((resolvePromise, reject) => {
        server.once('error', reject);
        server.listen(port, host, () => resolvePromise(server.address()));
      });
    },
    close() {
      return new Promise((resolvePromise) => {
        server.close(() => {
          try { db.close(); } catch { /* ignore */ }
          resolvePromise();
        });
      });
    },
  };
}

function adminShell(ctx) {
  const nonce = ctx.nonce;
  return `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<meta name="theme-color" content="#0B2A43">
<title>لوحة إدارة لوريت</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/css/app.css?v=${ASSET_V}">
<link rel="icon" href="/art/haram.svg?v=0" type="image/svg+xml">
</head>
<body class="admin-body">
<main id="adminRoot" aria-live="polite">
  <div class="login-wrap"><div class="login-card"><h1>لوحة إدارة لوريت</h1><p class="muted">جارٍ التحميل…</p></div></div>
</main>
<noscript><p style="padding:24px">تحتاج إلى تفعيل JavaScript لاستخدام لوحة الإدارة.</p></noscript>
<script src="/assets/js/admin.js?v=${ASSET_V}" nonce="${nonce}" defer></script>
</body>
</html>`;
}

/* ---------------- CLI ---------------- */
const isMain = process.argv[1] && resolve(process.argv[1]) === resolve(fileURLToPath(import.meta.url));
if (isMain) {
  const port = Number(process.env.PORT || 3000);
  const host = process.env.HOST || '127.0.0.1';
  const app = createApp({ baseUrl: process.env.BASE_URL || `http://${host}:${port}` });
  app.listen(port, host).then((addr) => {
    console.log(`\n  لوريت — المنصة تعمل الآن`);
    console.log(`  http://${host}:${addr.port}`);
    console.log(`  لوحة الإدارة: http://${host}:${addr.port}/admin`);
    if (!existsSync(join(HERE, 'data', 'admin-credentials.txt'))) {
      console.log('  بيانات الدخول: data/admin-credentials.txt');
    }
  }).catch((err) => {
    console.error('فشل تشغيل الخادم:', err.message);
    process.exit(1);
  });
}
