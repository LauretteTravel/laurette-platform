/* لوحة إدارة لوريت */
(() => {
  'use strict';

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
  const root = $('#adminRoot');
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const num = (n) => Number(n || 0).toLocaleString('en-US');
  const dt = (iso) => (iso ? new Date(iso).toLocaleString('ar-JO', { dateStyle: 'short', timeStyle: 'short' }) : '—');
  const day = (iso) => (iso ? new Date(iso).toLocaleDateString('ar-JO') : '—');

  const state = { user: null, section: 'overview', query: {}, overlay: null };

  async function api(path, options = {}) {
    const res = await fetch(path, {
      credentials: 'same-origin',
      headers: {
        ...(options.body ? { 'content-type': 'application/json' } : {}),
        'x-requested-with': 'fetch',
        ...(options.headers || {}),
      },
      ...options,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || data.ok === false) {
      const err = new Error(data.message || `خطأ ${res.status}`);
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  }

  function toast(message, kind = 'ok') {
    let stack = $('#toastStack');
    if (!stack) {
      stack = document.createElement('div');
      stack.id = 'toastStack';
      stack.className = 'toast-stack';
      stack.setAttribute('aria-live', 'polite');
      document.body.append(stack);
    }
    const el = document.createElement('div');
    el.className = `toast toast-${kind}`;
    el.textContent = message;
    stack.append(el);
    setTimeout(() => { el.classList.add('is-out'); setTimeout(() => el.remove(), 280); }, 3800);
  }

  /* ---------------- login ---------------- */
  function renderLogin(message = '') {
    root.innerHTML = `<div class="login-wrap">
      <form class="login-card" id="loginForm" autocomplete="on">
        <div class="brand" style="margin-bottom:18px"><span class="brand-mark">ل</span>
          <span class="brand-text"><b>لوريت</b><span>لوحة الإدارة</span></span></div>
        <h1>تسجيل الدخول</h1>
        <p class="muted" style="font-size:13px">للوصول إلى الطلبات والعملاء والبرامج. المحاولات محدودة لحماية الحساب.</p>
        <div class="field"><label for="lu">اسم المستخدم</label><input id="lu" name="username" autocomplete="username" dir="ltr" required></div>
        <div class="field"><label for="lp">كلمة المرور</label><input id="lp" name="password" type="password" autocomplete="current-password" dir="ltr" required></div>
        <p class="form-status is-error" id="lerr">${esc(message)}</p>
        <button class="btn btn-primary btn-block" type="submit">دخول</button>
      </form>
    </div>`;
    $('#loginForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const button = e.target.querySelector('button');
      button.disabled = true;
      try {
        const data = await api('/api/auth/login', { method: 'POST', body: JSON.stringify(Object.fromEntries(fd.entries())) });
        state.user = data.user;
        boot();
      } catch (err) {
        $('#lerr').textContent = err.message;
      } finally {
        button.disabled = false;
      }
    });
  }

  /* ---------------- shell ---------------- */
  const SECTIONS = [
    { id: 'overview', label: 'نظرة عامة', icon: '▤', permission: 'overview:read' },
    { id: 'requests', label: 'الطلبات', icon: '✉', permission: 'requests:read' },
    { id: 'customers', label: 'العملاء (CRM)', icon: '☺', permission: 'customers:read' },
    { id: 'programs', label: 'البرامج', icon: '✈', permission: 'programs:read' },
    { id: 'content', label: 'المحتوى والعروض', icon: '✎', permission: 'content:write' },
    { id: 'visa', label: 'التأشيرات', icon: '▤', permission: 'visa:write' },
    { id: 'kb', label: 'قاعدة معرفة المساعد', icon: '◈', permission: 'kb:write' },
    { id: 'users', label: 'الموظفون والصلاحيات', icon: '⚿', permission: 'users:write' },
    { id: 'settings', label: 'الإعدادات', icon: '⚙', permission: 'settings:write' },
    { id: 'audit', label: 'سجل العمليات', icon: '≡', permission: 'audit:read' },
    { id: 'assistant', label: 'محادثات المساعد', icon: '✧', permission: 'overview:read' },
  ];

  function visibleSections() {
    const role = state.user?.role;
    if (role === 'admin') return SECTIONS;
    const allowed = { manager: ['overview', 'requests', 'customers', 'programs', 'content', 'visa', 'kb', 'audit', 'assistant'], agent: ['overview', 'requests', 'customers', 'kb', 'assistant'] }[role] || ['overview'];
    return SECTIONS.filter((s) => allowed.includes(s.id));
  }

  function renderShell() {
    const sections = visibleSections();
    if (!sections.find((s) => s.id === state.section)) state.section = sections[0].id;
    root.innerHTML = `<div class="admin-shell">
      <aside class="admin-side">
        <a class="brand" href="/" style="text-decoration:none">
          <span class="brand-mark">ل</span>
          <span class="brand-text"><b>لوريت</b><span>لوحة الإدارة</span></span>
        </a>
        <ul class="admin-nav">
          ${sections.map((s) => `<li><button type="button" data-section="${s.id}" class="${state.section === s.id ? 'is-active' : ''}"><span aria-hidden="true">${s.icon}</span>${esc(s.label)}${s.id === 'requests' ? '<span class="count" data-req-count>0</span>' : ''}</button></li>`).join('')}
        </ul>
        <div style="margin-top:auto;padding-top:18px;font-size:12px;color:rgba(255,255,255,.55)">
          <div style="margin-bottom:8px">${esc(state.user.name)} · ${esc({ admin: 'مدير', manager: 'مدير قسم', agent: 'موظف' }[state.user.role] || state.user.role)}</div>
          <button class="btn btn-ghost btn-sm" type="button" id="logoutBtn">خروج</button>
        </div>
      </aside>
      <main class="admin-main">
        <div class="admin-top">
          <h1 id="pageTitle">${esc(sections.find((s) => s.id === state.section)?.label || '')}</h1>
          <span class="spacer"></span>
          <span class="admin-user">${esc(state.user.department || '')}</span>
          <a class="btn btn-ghost btn-sm" href="/" target="_blank" rel="noopener">عرض الموقع</a>
        </div>
        <div id="view"></div>
      </main>
    </div>`;

    root.addEventListener('click', onNavClick);
    $('#logoutBtn').addEventListener('click', async () => {
      await api('/api/auth/logout', { method: 'POST' });
      state.user = null;
      renderLogin();
    });
    if (state.user.mustChange) toast('يرجى تغيير كلمة المرور المؤقتة من الإعدادات', 'warn');
    loadSection();
  }

  function onNavClick(e) {
    const btn = e.target.closest('[data-section]');
    if (!btn) return;
    state.section = btn.dataset.section;
    $$('.admin-nav button').forEach((b) => b.classList.toggle('is-active', b.dataset.section === state.section));
    $('#pageTitle').textContent = btn.textContent.replace(/\d+$/, '').trim();
    loadSection();
  }

  function loadSection() {
    const view = $('#view');
    if (!view) return;
    view.innerHTML = '<div class="admin-card"><div class="admin-card-body">جارٍ التحميل…</div></div>';
    const map = {
      overview: renderOverview, requests: renderRequests, customers: renderCustomers, programs: renderPrograms,
      content: renderContent, visa: () => renderResource('visa'), kb: () => renderResource('kb'),
      users: renderUsers, settings: renderSettings, audit: renderAudit, assistant: renderAssistant,
    };
    (map[state.section] || renderOverview)();
  }

  /* ---------------- overview ---------------- */
  async function renderOverview() {
    const data = await api('/api/admin/overview');
    const s = data.stats;
    const count = (k) => s.byStatus[k] || 0;
    const badge = $('[data-req-count]');
    if (badge) badge.textContent = num(s.total);
    $('#view').innerHTML = `
      <div class="stat-grid">
        <div class="stat"><span>طلبات جديدة</span><b>${num(count('new'))}</b><small>إجمالي الطلبات: ${num(s.total)}</small></div>
        <div class="stat"><span>تحتاج متابعة</span><b>${num(s.followUps)}</b><small>${num(s.overdue)} طلب متأخر أكثر من يومين</small></div>
        <div class="stat"><span>عروض أسعار مرسلة</span><b>${num(s.quotes)}</b><small>مؤكدة: ${num(count('confirmed'))}</small></div>
        <div class="stat"><span>عملاء مسجلون</span><b>${num(s.customers)}</b><small>اليوم: ${num(s.today)} طلب</small></div>
      </div>
      <div class="stat-grid" style="grid-template-columns:repeat(3,minmax(0,1fr))">
        ${Object.entries(data.types).map(([k, t]) => `<div class="stat"><span>${esc(t.label)}</span><b>${num(s.byType[k] || 0)}</b><small>${esc(t.department)}</small></div>`).join('')}
      </div>
      <div class="admin-card mb-3">
        <div class="admin-card-head"><h2>طلبات تحتاج إجراءً</h2><span class="spacer" style="flex:1"></span><button class="btn btn-ghost btn-sm" data-refresh>تحديث</button></div>
        <div class="admin-card-body" style="padding:0">
          <table class="admin-table"><thead><tr><th>المرجع</th><th>النوع</th><th>الملخص</th><th>الحالة</th><th>آخر تحديث</th></tr></thead>
          <tbody>${data.needsAction.length ? data.needsAction.map((r) => `<tr data-request="${r.id}">
            <td class="ref">${esc(r.reference)}</td><td>${esc(data.types[r.type]?.label || r.type)}</td>
            <td>${esc(r.summary || '')}</td><td><span class="status-dot status-${r.status}">${esc(data.statuses[r.status]?.label)}</span></td>
            <td>${dt(r.updated_at)}</td></tr>`).join('') : '<tr><td colspan="5" class="muted">لا توجد طلبات تحتاج متابعة الآن.</td></tr>'}
          </tbody></table>
        </div>
      </div>
      <div class="admin-card">
        <div class="admin-card-head"><h2>أحدث الطلبات</h2></div>
        <div class="admin-card-body" style="padding:0">
          <table class="admin-table"><thead><tr><th>المرجع</th><th>العميل</th><th>النوع</th><th>الحالة</th><th>التاريخ</th></tr></thead>
          <tbody>${data.recent.length ? data.recent.map((r) => `<tr data-request="${r.id}">
            <td class="ref">${esc(r.reference)}</td><td>${esc(r.customer || '—')}</td>
            <td>${esc(data.types[r.type]?.label || r.type)}</td>
            <td><span class="status-dot status-${r.status}">${esc(data.statuses[r.status]?.label)}</span></td>
            <td>${dt(r.created_at)}</td></tr>`).join('') : '<tr><td colspan="5" class="muted">لا توجد طلبات بعد. الطلبات الواردة من الموقع ستظهر هنا مباشرة.</td></tr>'}
          </tbody></table>
        </div>
      </div>`;
    bindRequestRows();
    $('[data-refresh]')?.addEventListener('click', renderOverview);
  }

  function bindRequestRows() {
    $$('[data-request]').forEach((row) => {
      row.addEventListener('click', () => openRequest(Number(row.dataset.request)));
    });
  }

  /* ---------------- requests ---------------- */
  async function renderRequests(page = 1) {
    const params = new URLSearchParams({ ...state.query, page: String(page) });
    const data = await api(`/api/admin/requests?${params}`);
    const badge = $('[data-req-count]');
    if (badge) badge.textContent = num(data.total);
    $('#view').innerHTML = `
      <div class="toolbar">
        <select data-filter="type"><option value="">كل الأنواع</option>${Object.entries(data.types || {}).map(([k, t]) => `<option value="${k}" ${state.query.type === k ? 'selected' : ''}>${esc(t.label)}</option>`).join('')}</select>
        <select data-filter="status"><option value="">كل الحالات</option>${Object.entries(data.statuses || {}).map(([k, v]) => `<option value="${k}" ${state.query.status === k ? 'selected' : ''}>${esc(v.label)}</option>`).join('')}</select>
        <input data-filter="q" placeholder="بحث بالمرجع أو الاسم أو الهاتف" value="${esc(state.query.q || '')}">
        <button class="btn btn-ghost btn-sm" data-apply>تصفية</button>
        <span class="spacer"></span>
        <span class="muted" style="font-size:12px">${num(data.total)} طلب · صفحة ${data.page}/${data.pages}</span>
      </div>
      <div class="admin-card"><div class="admin-card-body" style="padding:0">
        <table class="admin-table">
          <thead><tr><th>المرجع</th><th>النوع</th><th>العميل</th><th>الملخص</th><th>الحالة</th><th>العرض</th><th>الموظف</th><th>التاريخ</th></tr></thead>
          <tbody>${data.requests.length ? data.requests.map((r) => `<tr data-request="${r.id}">
            <td class="ref">${esc(r.reference)}</td>
            <td>${esc(data.types[r.type]?.label || r.type)}</td>
            <td>${esc(r.customer || '—')}<br><small class="muted" dir="ltr">${esc(r.phone || '')}</small></td>
            <td style="max-width:280px">${esc(r.summary || '')}</td>
            <td><span class="status-dot status-${r.status}">${esc(data.statuses[r.status]?.label)}</span></td>
            <td>${r.quote_amount ? `${num(r.quote_amount)} د.أ` : '—'}</td>
            <td>${esc(r.agent || '—')}</td>
            <td>${dt(r.created_at)}</td></tr>`).join('') : '<tr><td colspan="8" class="muted">لا توجد طلبات مطابقة.</td></tr>'}
          </tbody>
        </table>
      </div></div>
      <div class="toolbar mt-3" style="justify-content:center">
        <button class="btn btn-ghost btn-sm" data-page="${data.page - 1}" ${data.page <= 1 ? 'disabled' : ''}>السابق</button>
        <button class="btn btn-ghost btn-sm" data-page="${data.page + 1}" ${data.page >= data.pages ? 'disabled' : ''}>التالي</button>
      </div>`;
    bindRequestRows();
    $('[data-apply]')?.addEventListener('click', () => {
      state.query = {};
      $$('[data-filter]').forEach((el) => { if (el.value) state.query[el.dataset.filter] = el.value; });
      renderRequests(1);
    });
    $$('[data-page]').forEach((b) => b.addEventListener('click', () => renderRequests(Number(b.dataset.page))));
  }

  const FIELD_LABELS = {
    tripType: 'نوع الرحلة', origin: 'من', destination: 'إلى', departDate: 'تاريخ السفر', returnDate: 'تاريخ العودة',
    cabin: 'الدرجة', adults: 'البالغون', children: 'الأطفال', infants: 'الرضّع', baggage: 'الأمتعة', airline: 'شركة الطيران',
    segments: 'المسارات', country: 'الدولة', city: 'المدينة', hotelName: 'الفندق', checkIn: 'الدخول', checkOut: 'الخروج',
    rooms: 'الغرف', stars: 'التصنيف', mealPlan: 'الوجبات', budget: 'الميزانية', specialRequests: 'طلبات خاصة',
    childAges: 'أعمار الأطفال', programSlug: 'البرنامج', optionLabel: 'الخيار', preferredDate: 'التاريخ المفضل', roomType: 'نوع الغرفة',
    nationality: 'الجنسية', residence: 'الإقامة', visaType: 'نوع التأشيرة', purpose: 'الغرض', travelDate: 'تاريخ السفر',
    applicants: 'عدد المتقدمين', previousVisas: 'تأشيرات سابقة', topic: 'نوع الاستشارة', message: 'الرسالة', channel: 'قناة التواصل',
    preferredTime: 'وقت التواصل', name: 'الاسم', phone: 'الهاتف', email: 'البريد', city: 'المدينة', notes: 'ملاحظات', consent: 'الموافقة', hash: 'بصمة الطلب',
  };

  async function openRequest(id) {
    const data = await api(`/api/admin/requests/${id}`);
    const r = data.request;
    const statuses = data.statuses || {};
    const payload = r.payload || {};
    const rows = Object.entries(payload)
      .filter(([k]) => !['hash', 'userAgent', 'ip'].includes(k))
      .map(([k, v]) => `<dt>${esc(FIELD_LABELS[k] || k)}</dt><dd>${Array.isArray(v) ? v.map((x) => esc(typeof x === 'object' ? JSON.stringify(x) : x)).join('<br>') : esc(v === true ? 'نعم' : v === false ? 'لا' : v)}</dd>`)
      .join('');
    openDrawer(`
      <div class="drawer-head">
        <div><h2>${esc(r.title || '')}</h2><div class="ref">${esc(r.reference)}</div></div>
        <button class="drawer-close" type="button" data-close-drawer aria-label="إغلاق">×</button>
      </div>
      <div class="badge-row mb-2">
        <span class="status-dot status-${r.status}">${esc(statuses[r.status]?.label || r.status)}</span>
        <span class="badge badge-soft">${esc(r.type)}</span>
        ${r.quote_amount ? `<span class="badge badge-gold">عرض: ${num(r.quote_amount)} ${esc(r.quote_currency || 'د.أ')}</span>` : ''}
      </div>
      <p>${esc(r.summary || '')}</p>
      <dl class="kv">${rows}</dl>
      <hr>
      <h3>تحديث الحالة</h3>
      <div class="form-grid">
        <div class="field"><label>الحالة التالية</label>
          <select id="dStatus">${data.nextStatuses.map((s) => `<option value="${s}">${esc(statuses[s]?.label || s)}</option>`).join('') || '<option value="">لا يوجد انتقال متاح</option>'}</select>
        </div>
        <div class="field"><label>إسناد إلى</label>
          <select id="dAgent"><option value="">بدون إسناد</option>${data.agents.map((a) => `<option value="${a.id}" ${r.assigned_to === a.id ? 'selected' : ''}>${esc(a.name)}${a.department ? ` — ${esc(a.department)}` : ''}</option>`).join('')}</select>
        </div>
        <div class="field"><label>قيمة عرض السعر (د.أ)</label><input id="dQuote" type="number" min="0" step="1" value="${r.quote_amount ?? ''}"></div>
        <div class="field"><label>ملاحظة العرض</label><input id="dQuoteNote" value="${esc(r.quote_note || '')}" placeholder="مثال: شامل الطيران والتأشيرة"></div>
      </div>
      <div class="btn-row mt-2"><button class="btn btn-primary btn-sm" data-save-status ${data.nextStatuses.length ? '' : 'disabled'}>حفظ الحالة</button><button class="btn btn-ghost btn-sm" data-save-quote>حفظ العرض</button><button class="btn btn-ghost btn-sm" data-save-assign>حفظ الإسناد</button></div>
      <hr>
      <h3>إضافة ملاحظة داخلية</h3>
      <div class="field"><textarea id="dNote" rows="3" placeholder="ملاحظة تظهر للفريق فقط"></textarea></div>
      <button class="btn btn-primary btn-sm mt-2" data-add-note>إضافة الملاحظة</button>
      <hr>
      <h3>السجل</h3>
      <ul class="timeline">${data.events.map((e) => `<li><b>${esc(e.message || e.kind)}</b><span>${esc(e.actor_name || 'النظام')} · ${dt(e.created_at)}</span></li>`).join('')}</ul>
      ${payload.phone ? `<div class="btn-row mt-3"><a class="btn btn-wa btn-sm" href="https://wa.me/${String(payload.phone).replace(/\D/g, '')}" target="_blank" rel="noopener">واتساب العميل</a><a class="btn btn-ghost btn-sm" href="tel:${esc(payload.phone)}">اتصال</a></div>` : ''}
    `);

    const refresh = () => { closeDrawer(); openRequest(id); };
    $('[data-save-status]')?.addEventListener('click', async () => {
      const status = $('#dStatus').value;
      if (!status) return;
      try { await api(`/api/admin/requests/${id}`, { method: 'PATCH', body: JSON.stringify({ status }) }); toast('تم تحديث الحالة'); refresh(); } catch (e) { toast(e.message, 'bad'); }
    });
    $('[data-save-quote]')?.addEventListener('click', async () => {
      try {
        await api(`/api/admin/requests/${id}`, { method: 'PATCH', body: JSON.stringify({ quoteAmount: $('#dQuote').value, quoteNote: $('#dQuoteNote').value }) });
        toast('تم حفظ عرض السعر'); refresh();
      } catch (e) { toast(e.message, 'bad'); }
    });
    $('[data-save-assign]')?.addEventListener('click', async () => {
      try { await api(`/api/admin/requests/${id}`, { method: 'PATCH', body: JSON.stringify({ assignedTo: $('#dAgent').value || null }) }); toast('تم حفظ الإسناد'); refresh(); } catch (e) { toast(e.message, 'bad'); }
    });
    $('[data-add-note]')?.addEventListener('click', async () => {
      const note = $('#dNote').value.trim();
      if (!note) return;
      try { await api(`/api/admin/requests/${id}`, { method: 'PATCH', body: JSON.stringify({ note }) }); toast('أُضيفت الملاحظة'); refresh(); } catch (e) { toast(e.message, 'bad'); }
    });
  }

  /* ---------------- customers ---------------- */
  async function renderCustomers() {
    const data = await api(`/api/admin/customers${state.query.cq ? `?q=${encodeURIComponent(state.query.cq)}` : ''}`);
    $('#view').innerHTML = `
      <div class="toolbar">
        <input id="cSearch" placeholder="بحث بالاسم أو الهاتف أو البريد" value="${esc(state.query.cq || '')}">
        <button class="btn btn-ghost btn-sm" data-csearch>بحث</button>
        <span class="spacer"></span><span class="muted" style="font-size:12px">${num(data.customers.length)} عميل</span>
      </div>
      <div class="admin-card"><div class="admin-card-body" style="padding:0">
        <table class="admin-table"><thead><tr><th>الاسم</th><th>الهاتف</th><th>البريد</th><th>الطلبات</th><th>آخر طلب</th><th>ملاحظات</th></tr></thead>
        <tbody>${data.customers.length ? data.customers.map((c) => `<tr data-customer="${c.id}">
          <td>${esc(c.name)}</td><td dir="ltr">${esc(c.phone)}</td><td dir="ltr">${esc(c.email || '—')}</td>
          <td>${num(c.n)}</td><td>${day(c.last_request)}</td><td class="muted" style="max-width:220px">${esc(c.notes || '')}</td>
        </tr>`).join('') : '<tr><td colspan="6" class="muted">لا يوجد عملاء بعد.</td></tr>'}</tbody></table>
      </div></div>`;
    $('[data-csearch]')?.addEventListener('click', () => { state.query.cq = $('#cSearch').value.trim(); renderCustomers(); });
    $$('[data-customer]').forEach((row) => row.addEventListener('click', () => openCustomer(Number(row.dataset.customer))));
  }

  async function openCustomer(id) {
    const data = await api(`/api/admin/customers/${id}`);
    const c = data.customer;
    openDrawer(`
      <div class="drawer-head"><div><h2>${esc(c.name)}</h2><div class="ref" dir="ltr">${esc(c.phone)}</div></div><button class="drawer-close" data-close-drawer>×</button></div>
      <dl class="kv"><dt>البريد</dt><dd dir="ltr">${esc(c.email || '—')}</dd><dt>الدولة</dt><dd>${esc(c.country || '—')}</dd><dt>الموافقة</dt><dd>${c.consent ? 'نعم' : 'لا'}</dd><dt>أول تواصل</dt><dd>${dt(c.created_at)}</dd></dl>
      <div class="field"><label>ملاحظات الموظف</label><textarea id="cNotes" rows="4">${esc(c.notes || '')}</textarea></div>
      <div class="field mt-2"><label>تفضيلات العميل</label><input id="cPref" value="${esc(c.preference || '')}" placeholder="مثال: يفضل فنادق قريبة من الحرم"></div>
      <button class="btn btn-primary btn-sm mt-2" data-save-customer>حفظ</button>
      <hr><h3>الطلبات</h3>
      <table class="admin-table"><thead><tr><th>المرجع</th><th>النوع</th><th>الحالة</th><th>الملخص</th></tr></thead>
      <tbody>${data.requests.map((r) => `<tr data-request="${r.id}"><td class="ref">${esc(r.reference)}</td><td>${esc(r.type)}</td><td>${esc(r.status)}</td><td>${esc(r.summary || '')}</td></tr>`).join('') || '<tr><td colspan="4" class="muted">لا طلبات</td></tr>'}</tbody></table>
    `);
    $('[data-save-customer]')?.addEventListener('click', async () => {
      try {
        await api(`/api/admin/customers/${id}`, { method: 'PATCH', body: JSON.stringify({ notes: $('#cNotes').value, preference: $('#cPref').value }) });
        toast('تم الحفظ');
      } catch (e) { toast(e.message, 'bad'); }
    });
    bindRequestRows();
  }

  /* ---------------- programs ---------------- */
  const PROGRAM_FIELDS = [
    { key: 'title', label: 'العنوان', full: true },
    { key: 'slug', label: 'المعرّف في الرابط (slug)', hint: 'يُنشأ تلقائيًا إذا تُرك فارغًا' },
    { key: 'category', label: 'القسم', type: 'select', options: [['umrah', 'الحج والعمرة'], ['cruise', 'رحلات الكروز'], ['sharm', 'شرم الشيخ'], ['istanbul', 'إسطنبول']] },
    { key: 'level', label: 'المستوى', type: 'select', options: [['', 'غير محدد'], ['eco', 'اقتصادي'], ['3', 'ثلاث نجوم'], ['4', 'أربع نجوم'], ['5', 'خمس نجوم']] },
    { key: 'status', label: 'الحالة', type: 'select', options: [['published', 'منشور'], ['draft', 'مسودة'], ['sold_out', 'نفدت المقاعد'], ['archived', 'مؤرشف']] },
    { key: 'summary', label: 'ملخص قصير', full: true },
    { key: 'days', label: 'الأيام', type: 'number' },
    { key: 'nights', label: 'الليالي', type: 'number' },
    { key: 'priceFrom', label: 'السعر يبدأ من', type: 'number' },
    { key: 'artKey', label: 'الرسم', type: 'select', options: [['haram', 'الحرم'], ['madinah', 'المدينة'], ['istanbul', 'إسطنبول'], ['beach', 'شاطئ'], ['cruise', 'سفينة'], ['plane', 'طائرة'], ['hotel', 'فندق'], ['desert', 'صحراء'], ['cairo', 'القاهرة'], ['europe', 'أوروبا'], ['asia', 'آسيا'], ['gulf', 'الخليج']] },
    { key: 'destination', label: 'الوجهة' },
    { key: 'country', label: 'الدولة' },
    { key: 'meals', label: 'الوجبات' },
    { key: 'airline', label: 'شركة الطيران' },
    { key: 'departureDates', label: 'مواعيد المغادرة', full: true },
    { key: 'hotels', label: 'الفنادق', type: 'list', rows: 4, hint: 'سطر لكل فندق: المدينة | الاسم | النجوم | المسافة' },
    { key: 'options', label: 'خيارات الأسعار', type: 'list', rows: 5, hint: 'سطر لكل خيار: الوصف | السعر' },
    { key: 'itinerary', label: 'خط السير', type: 'list', rows: 6, hint: 'سطر لكل يوم بالترتيب' },
    { key: 'includes', label: 'المشمول', type: 'list', rows: 5 },
    { key: 'excludes', label: 'غير المشمول', type: 'list', rows: 5 },
    { key: 'terms', label: 'الشروط', type: 'list', rows: 4 },
    { key: 'flights', label: 'الرحلات الجوية', type: 'list', rows: 4 },
    { key: 'badges', label: 'الشارات', type: 'list', rows: 2 },
    { key: 'description', label: 'وصف داخلي', type: 'textarea', rows: 3 },
  ];

  async function renderPrograms() {
    const data = await api('/api/admin/programs');
    const items = data.items;
    $('#view').innerHTML = `
      <div class="toolbar">
        <button class="btn btn-primary btn-sm" data-new-program>+ برنامج جديد</button>
        <span class="spacer"></span>
        <span class="muted" style="font-size:12px">${num(items.length)} برنامج</span>
      </div>
      <div class="admin-card"><div class="admin-card-body" style="padding:0">
        <table class="admin-table"><thead><tr><th>العنوان</th><th>القسم</th><th>السعر</th><th>الحالة</th><th>مميز</th><th>تعديل</th></tr></thead>
        <tbody>${items.map((p) => `<tr>
          <td><b>${esc(p.title)}</b><br><small class="muted" dir="ltr">${esc(p.slug)}</small></td>
          <td>${esc(p.category)}</td><td>${p.price_from ? `${num(p.price_from)} ${esc(p.currency)}` : '—'}</td>
          <td><span class="badge ${p.status === 'published' ? 'badge-ok' : p.status === 'sold_out' ? 'badge-danger' : 'badge-line'}">${esc({ published: 'منشور', draft: 'مسودة', sold_out: 'نفدت', archived: 'مؤرشف' }[p.status] || p.status)}</span></td>
          <td>${p.featured ? '★' : '—'}</td>
          <td class="btn-row"><button class="btn btn-ghost btn-sm" data-edit-program="${p.id}">تعديل</button><button class="btn btn-danger btn-sm" data-del-program="${p.id}">حذف</button></td>
        </tr>`).join('')}</tbody></table>
      </div></div>`;
    $('[data-new-program]')?.addEventListener('click', () => openProgramForm(null));
    $$('[data-edit-program]').forEach((b) => b.addEventListener('click', () => openProgramForm(items.find((p) => p.id === Number(b.dataset.editProgram)))));
    $$('[data-del-program]').forEach((b) => b.addEventListener('click', async () => {
      if (!confirm('حذف أو أرشفة هذا البرنامج؟')) return;
      try { const r = await api(`/api/admin/programs/${b.dataset.delProgram}`, { method: 'DELETE' }); toast(r.message || 'تم'); renderPrograms(); } catch (e) { toast(e.message, 'bad'); }
    }));
  }

  function fieldControl(field, value) {
    const id = `ff-${field.key}`;
    if (field.type === 'select') {
      return `<select id="${id}" data-key="${field.key}">${field.options.map(([v, l]) => `<option value="${v}" ${String(v) === String(value ?? '') ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select>`;
    }
    if (field.type === 'textarea') return `<textarea id="${id}" data-key="${field.key}" rows="${field.rows || 4}">${esc(value ?? '')}</textarea>`;
    if (field.type === 'list') return `<textarea id="${id}" data-key="${field.key}" rows="${field.rows || 4}">${esc(Array.isArray(value) ? value.map((v) => (typeof v === 'object' ? (field.key === 'hotels' ? `${v.city} | ${v.name} | ${v.stars || 0} | ${v.distance || ''}` : `${v.label} | ${v.price}`) : v)).join('\n') : (value || ''))}</textarea>`;
    return `<input id="${id}" data-key="${field.key}" type="${field.type || 'text'}" value="${esc(value ?? '')}"${field.datalist ? ' list="mediaList"' : ''}>`;
  }

  function openProgramForm(program) {
    const p = program || { category: 'umrah', status: 'published', artKey: 'haram', currency: 'د.أ' };
    openDrawer(`
      <div class="drawer-head"><div><h2>${program ? 'تعديل برنامج' : 'برنامج جديد'}</h2></div><button class="drawer-close" data-close-drawer>×</button></div>
      <form id="programForm" class="stack">
        <div class="form-grid">
          ${PROGRAM_FIELDS.map((f) => `<div class="field ${f.full ? 'field-full' : ''}">
            <label for="ff-${f.key}">${esc(f.label)}</label>
            ${fieldControl(f, p[f.key])}
            ${f.hint ? `<span class="field-hint">${esc(f.hint)}</span>` : ''}
          </div>`).join('')}
        </div>
        <div class="check"><label class="check"><input type="checkbox" id="ff-featured" ${p.featured ? 'checked' : ''}> <span>برنامج مميز (يظهر في الرئيسية)</span></label></div>
        <p class="form-status is-error" data-form-error></p>
        <div class="btn-row"><button class="btn btn-primary" type="submit">حفظ</button><button class="btn btn-ghost" type="button" data-close-drawer>إلغاء</button></div>
      </form>
    `);
    $('#programForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const body = {};
      PROGRAM_FIELDS.forEach((f) => {
        const el = $(`[data-key="${f.key}"]`);
        if (!el) return;
        if (f.type === 'list') body[f.key] = el.value.split('\n').map((s) => s.trim()).filter(Boolean);
        else if (f.type === 'number') body[f.key] = el.value === '' ? null : Number(el.value);
        else body[f.key] = el.value.trim();
      });
      body.featured = $('#ff-featured').checked;
      try {
        if (program) await api(`/api/admin/programs/${program.id}`, { method: 'PATCH', body: JSON.stringify(body) });
        else await api('/api/admin/programs', { method: 'POST', body: JSON.stringify(body) });
        closeDrawer();
        toast('تم الحفظ');
        renderPrograms();
      } catch (err) {
        $('[data-form-error]').textContent = err.message;
      }
    });
  }

  /* ---------------- generic content resources ---------------- */
  const CONTENT = {
    offers: {
      label: 'العروض', titleKey: 'title', fields: [
        { key: 'title', label: 'عنوان العرض', full: true },
        { key: 'slug', label: 'slug' },
        { key: 'category', label: 'التصنيف', type: 'select', options: [['turkey', 'تركيا'], ['egypt', 'مصر'], ['georgia', 'جورجيا'], ['umrah', 'الحج والعمرة'], ['cruise', 'رحلات الكروز'], ['visa', 'التأشيرات']] },
        { key: 'priceFrom', label: 'السعر يبدأ من', type: 'number' },
        { key: 'days', label: 'الأيام', type: 'number' },
        { key: 'nights', label: 'الليالي', type: 'number' },
        { key: 'imageUrl', label: 'صورة البوستر', datalist: true, full: true, hint: 'اختر من مكتبة البوسترات أو الصق رابطًا. الصورة الرأسية 4:5 هي الأفضل.' },
        { key: 'imageAlt', label: 'وصف الصورة (لكبار المساعدة)', full: true },
        { key: 'body', label: 'وصف العرض', type: 'textarea', rows: 3, full: true },
        { key: 'includes', label: 'يشمل', type: 'list', rows: 5 },
        { key: 'sort', label: 'الترتيب', type: 'number' },
        { key: 'featured', label: 'مميز في الرئيسية', type: 'select', options: [['0', 'لا'], ['1', 'نعم']] },
        { key: 'validUntil', label: 'صالحة حتى (اختياري)', type: 'date' },
      ], toggle: ['active', 'مفعّل'],
    },
    news: {
      label: 'أخبار الطيران', titleKey: 'title', fields: [
        { key: 'title', label: 'العنوان', full: true }, { key: 'airline', label: 'شركة الطيران' },
        { key: 'publishedAt', label: 'التاريخ', type: 'date' }, { key: 'body', label: 'النص', type: 'textarea', rows: 6 },
      ], toggle: ['urgent', 'عاجل'],
    },
    articles: {
      label: 'مقالات الدليل', titleKey: 'title', fields: [
        { key: 'title', label: 'العنوان', full: true }, { key: 'slug', label: 'slug' },
        { key: 'category', label: 'التصنيف' }, { key: 'readingMinutes', label: 'دقائق القراءة', type: 'number' },
        { key: 'excerpt', label: 'مقتطف', full: true, type: 'textarea', rows: 2 },
        { key: 'body', label: 'المحتوى (Markdown)', type: 'textarea', rows: 10 }, { key: 'tags', label: 'كلمات مفتاحية', type: 'list', rows: 2 },
      ],
    },
    faq: {
      label: 'الأسئلة الشائعة', titleKey: 'question', fields: [
        { key: 'question', label: 'السؤال', full: true }, { key: 'answer', label: 'الجواب', type: 'textarea', rows: 5 },
        { key: 'category', label: 'التصنيف', type: 'select', options: [['general', 'عام'], ['visa', 'تأشيرات'], ['umrah', 'عمرة'], ['flights', 'طيران'], ['hotels', 'فنادق']] },
        { key: 'sort', label: 'الترتيب', type: 'number' },
      ],
    },
    destinations: {
      label: 'الوجهات', titleKey: 'name', fields: [
        { key: 'name', label: 'الاسم' }, { key: 'slug', label: 'slug' },
        { key: 'kind', label: 'النوع', type: 'select', options: [['city', 'مدينة'], ['country', 'دولة']] },
        { key: 'parentSlug', label: 'الدولة (slug)' }, { key: 'bestTime', label: 'أفضل وقت' },
        { key: 'summary', label: 'الوصف', type: 'textarea', rows: 4, full: true },
        { key: 'highlights', label: 'أبرز المعالم', type: 'list', rows: 4 },
        { key: 'mapUrl', label: 'رابط الخريطة', full: true },
      ],
    },
    reviews: {
      label: 'المراجعات', titleKey: 'name', fields: [
        { key: 'name', label: 'الاسم' }, { key: 'branch', label: 'الفرع' },
        { key: 'text', label: 'نص المراجعة', type: 'textarea', rows: 4, full: true },
        { key: 'source', label: 'المصدر' }, { key: 'publishedAt', label: 'التاريخ', type: 'date' },
      ], toggle: ['visible', 'ظاهرة'],
    },
  };

  const VISA_FIELDS = [
    { key: 'destination', label: 'الوجهة' }, { key: 'purpose', label: 'الغرض' },
    { key: 'summary', label: 'الملخص', type: 'textarea', rows: 5, full: true },
    { key: 'docs', label: 'المستندات', type: 'list', rows: 6 }, { key: 'notes', label: 'ملاحظات', type: 'list', rows: 4 },
    { key: 'sourceName', label: 'اسم المصدر' }, { key: 'sourceUrl', label: 'رابط المصدر', full: true },
    { key: 'lastVerified', label: 'آخر تحقق', type: 'date' },
  ];
  const KB_FIELDS = [
    { key: 'title', label: 'العنوان', full: true },
    { key: 'body', label: 'المحتوى', type: 'textarea', rows: 8, full: true },
    { key: 'category', label: 'التصنيف', type: 'select', options: [['policy', 'سياسة'], ['umrah', 'عمرة'], ['hotels', 'فنادق'], ['general', 'عام']] },
    { key: 'tags', label: 'كلمات', type: 'list', rows: 2 },
  ];

  async function renderContent() {
    const tabs = Object.entries(CONTENT);
    const current = state.contentTab || 'offers';
    const data = await api(`/api/admin/${current}`);
    $('#view').innerHTML = `
      <div class="tabs">${tabs.map(([k, v]) => `<button data-ctab="${k}" class="${current === k ? 'is-active' : ''}">${esc(v.label)}</button>`).join('')}</div>
      <div class="toolbar"><button class="btn btn-primary btn-sm" data-new-content>+ إضافة</button><span class="spacer"></span><span class="muted" style="font-size:12px">${num(data.items.length)} عنصر</span></div>
      <div class="admin-card"><div class="admin-card-body" style="padding:0">
        <table class="admin-table"><thead><tr><th>العنوان</th><th>تفاصيل</th><th>الحالة</th><th></th></tr></thead>
        <tbody>${data.items.map((it) => {
          const spec = CONTENT[current];
          const title = it[spec.titleKey] || it.title || it.name || it.question || '—';
          const extra = [it.valid_until ? `حتى ${it.valid_until}` : '', it.published_at || '', it.category || '', it.branch || '', it.last_verified || ''].filter(Boolean).join(' · ');
          const status = spec.toggle ? (it[spec.toggle[0]] ? spec.toggle[1] : 'معطّل') : (it.status || (it.published ? 'منشور' : 'مسودة'));
          return `<tr><td><b>${esc(title)}</b></td><td class="muted">${esc(extra)}</td><td>${esc(status)}</td>
            <td class="btn-row"><button class="btn btn-ghost btn-sm" data-edit-content="${it.id}">تعديل</button><button class="btn btn-danger btn-sm" data-del-content="${it.id}">حذف</button></td></tr>`;
        }).join('') || '<tr><td colspan="4" class="muted">لا عناصر</td></tr>'}</tbody></table>
      </div></div>`;
    $$('[data-ctab]').forEach((b) => b.addEventListener('click', () => { state.contentTab = b.dataset.ctab; renderContent(); }));
    $('[data-new-content]')?.addEventListener('click', () => openContentForm(current, null, data.items));
    $$('[data-edit-content]').forEach((b) => b.addEventListener('click', () => openContentForm(current, data.items.find((i) => i.id === Number(b.dataset.editContent)), data.items)));
    $$('[data-del-content]').forEach((b) => b.addEventListener('click', async () => {
      if (!confirm('تأكيد الحذف؟')) return;
      try { await api(`/api/admin/${current}/${b.dataset.delContent}`, { method: 'DELETE' }); toast('تم الحذف'); renderContent(); } catch (e) { toast(e.message, 'bad'); }
    }));
  }

  function openContentForm(resource, item, items) {
    const spec = CONTENT[resource];
    openDrawer(`
      <div class="drawer-head"><div><h2>${item ? 'تعديل' : 'إضافة'} — ${esc(spec.label)}</h2></div><button class="drawer-close" data-close-drawer>×</button></div>
      <form id="contentForm" class="stack"><div class="form-grid">
        ${spec.fields.map((f) => `<div class="field ${f.full ? 'field-full' : ''}"><label for="cf-${f.key}">${esc(f.label)}</label>${fieldControl(f, item?.[f.key])}</div>`).join('')}
      </div>
      ${spec.toggle ? `<label class="check"><input type="checkbox" id="cf-toggle" ${item?.[spec.toggle[0]] ? 'checked' : ''}><span>${esc(spec.toggle[1])}</span></label>` : ''}
      <p class="form-status is-error" data-form-error></p>
      <div class="btn-row"><button class="btn btn-primary" type="submit">حفظ</button><button class="btn btn-ghost" type="button" data-close-drawer>إلغاء</button></div></form>`);
    $('#contentForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const body = {};
      spec.fields.forEach((f) => {
        const el = $(`[data-key="${f.key}"]`);
        if (!el) return;
        if (f.type === 'list') body[f.key] = el.value.split('\n').map((s) => s.trim()).filter(Boolean);
        else if (f.type === 'number') body[f.key] = el.value === '' ? null : Number(el.value);
        else body[f.key] = el.value.trim();
      });
      if (spec.toggle) body[spec.toggle[0]] = $('#cf-toggle').checked;
      if (resource === 'visa') body.requiresVerification = true;
      if (resource === 'destinations') body.published = true;
      try {
        if (item) await api(`/api/admin/${resource}/${item.id}`, { method: 'PATCH', body: JSON.stringify(body) });
        else await api(`/api/admin/${resource}`, { method: 'POST', body: JSON.stringify(body) });
        closeDrawer(); toast('تم الحفظ'); renderContent();
      } catch (err) { $('[data-form-error]').textContent = err.message; }
    });

    if (resource === 'offers') {
      api('/api/admin/media').then((media) => {
        const datalist = document.createElement('datalist');
        datalist.id = 'mediaList';
        datalist.innerHTML = media.files.map((f) => `<option value="${esc(f)}"></option>`).join('');
        $('#contentForm').append(datalist);
      }).catch(() => {});
    }
  }

  async function renderResource(kind) {
    const fields = kind === 'visa' ? VISA_FIELDS : KB_FIELDS;
    const data = await api(`/api/admin/${kind}`);
    const titleKey = kind === 'visa' ? 'destination' : 'title';
    $('#view').innerHTML = `
      <div class="toolbar"><button class="btn btn-primary btn-sm" data-new>+ إضافة</button><span class="spacer"></span><span class="muted" style="font-size:12px">${num(data.items.length)} عنصر</span></div>
      <div class="admin-card"><div class="admin-card-body" style="padding:0">
        <table class="admin-table"><thead><tr><th>${kind === 'visa' ? 'الوجهة' : 'العنوان'}</th><th>معلومات</th><th></th></tr></thead>
        <tbody>${data.items.map((it) => `<tr><td><b>${esc(it[titleKey])}</b></td>
          <td class="muted">${esc(kind === 'visa' ? `${it.purpose || ''} · آخر تحقق ${it.last_verified || '—'}` : `${it.category || ''} · ${(it.body || '').slice(0, 80)}…`)}</td>
          <td class="btn-row"><button class="btn btn-ghost btn-sm" data-edit="${it.id}">تعديل</button><button class="btn btn-danger btn-sm" data-del="${it.id}">حذف</button></td></tr>`).join('') || '<tr><td colspan="3" class="muted">لا عناصر</td></tr>'}</tbody></table>
      </div></div>`;
    $('[data-new]')?.addEventListener('click', () => openResourceForm(kind, fields, null));
    $$('[data-edit]').forEach((b) => b.addEventListener('click', () => openResourceForm(kind, fields, data.items.find((i) => i.id === Number(b.dataset.edit)))));
    $$('[data-del]').forEach((b) => b.addEventListener('click', async () => {
      if (!confirm('تأكيد الحذف؟')) return;
      try { await api(`/api/admin/${kind}/${b.dataset.del}`, { method: 'DELETE' }); toast('تم الحذف'); renderResource(kind); } catch (e) { toast(e.message, 'bad'); }
    }));
  }

  function openResourceForm(kind, fields, item) {
    openDrawer(`
      <div class="drawer-head"><div><h2>${item ? 'تعديل' : 'إضافة'}</h2></div><button class="drawer-close" data-close-drawer>×</button></div>
      <form id="resourceForm" class="stack"><div class="form-grid">
        ${fields.map((f) => `<div class="field ${f.full ? 'field-full' : ''}"><label for="cf-${f.key}">${esc(f.label)}</label>${fieldControl(f, item?.[f.key])}</div>`).join('')}
      </div><p class="form-status is-error" data-form-error></p>
      <div class="btn-row"><button class="btn btn-primary" type="submit">حفظ</button><button class="btn btn-ghost" type="button" data-close-drawer>إلغاء</button></div></form>`);
    $('#resourceForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const body = {};
      fields.forEach((f) => {
        const el = $(`[data-key="${f.key}"]`);
        if (!el) return;
        if (f.type === 'list') body[f.key] = el.value.split('\n').map((s) => s.trim()).filter(Boolean);
        else body[f.key] = el.value.trim();
      });
      try {
        if (item) await api(`/api/admin/${kind}/${item.id}`, { method: 'PATCH', body: JSON.stringify(body) });
        else await api(`/api/admin/${kind}`, { method: 'POST', body: JSON.stringify(body) });
        closeDrawer(); toast('تم الحفظ'); renderResource(kind);
      } catch (err) { $('[data-form-error]').textContent = err.message; }
    });
  }

  /* ---------------- users / settings / audit / assistant ---------------- */
  async function renderUsers() {
    const data = await api('/api/admin/users');
    $('#view').innerHTML = `
      <div class="toolbar"><button class="btn btn-primary btn-sm" data-new-user>+ موظف جديد</button></div>
      <div class="admin-card"><div class="admin-card-body" style="padding:0">
        <table class="admin-table"><thead><tr><th>الاسم</th><th>اسم الدخول</th><th>الدور</th><th>القسم</th><th>آخر دخول</th><th>نشط</th><th></th></tr></thead>
        <tbody>${data.users.map((u) => `<tr><td><b>${esc(u.name)}</b></td><td dir="ltr">${esc(u.username)}</td>
          <td>${esc({ admin: 'مدير', manager: 'مدير قسم', agent: 'موظف' }[u.role] || u.role)}</td>
          <td>${esc(u.department || '—')}</td><td>${dt(u.last_login_at)}</td><td>${u.active ? '✓' : '✕'}</td>
          <td class="btn-row"><button class="btn btn-ghost btn-sm" data-edit-user="${u.id}">تعديل</button>
          ${u.active ? `<button class="btn btn-danger btn-sm" data-toggle-user="${u.id}" data-active="0">تعطيل</button>` : `<button class="btn btn-ghost btn-sm" data-toggle-user="${u.id}" data-active="1">تنشيط</button>`}</td></tr>`).join('')}</tbody></table>
      </div></div>`;
    $('[data-new-user]')?.addEventListener('click', () => openUserForm(null));
    $$('[data-edit-user]').forEach((b) => b.addEventListener('click', () => openUserForm(data.users.find((u) => u.id === Number(b.dataset.editUser)))));
    $$('[data-toggle-user]').forEach((b) => b.addEventListener('click', async () => {
      try { await api(`/api/admin/users/${b.dataset.toggleUser}`, { method: 'PATCH', body: JSON.stringify({ active: b.dataset.active === '1' }) }); toast('تم'); renderUsers(); } catch (e) { toast(e.message, 'bad'); }
    }));
  }

  function openUserForm(user) {
    openDrawer(`
      <div class="drawer-head"><div><h2>${user ? 'تعديل موظف' : 'موظف جديد'}</h2></div><button class="drawer-close" data-close-drawer>×</button></div>
      <form id="userForm" class="stack">
        <div class="form-grid">
          <div class="field"><label>الاسم</label><input data-key="name" value="${esc(user?.name || '')}"></div>
          ${user ? '' : '<div class="field"><label>اسم الدخول (لاتيني)</label><input data-key="username" dir="ltr"></div>'}
          <div class="field"><label>الدور</label><select data-key="role">${[['agent', 'موظف'], ['manager', 'مدير قسم'], ['admin', 'مدير']].map(([v, l]) => `<option value="${v}" ${user?.role === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
          <div class="field"><label>القسم</label><input data-key="department" value="${esc(user?.department || '')}"></div>
          <div class="field"><label>${user ? 'كلمة مرور جديدة (اختياري)' : 'كلمة المرور'}</label><input data-key="password" type="password" dir="ltr" autocomplete="new-password"></div>
        </div>
        <p class="field-hint">10 أحرف على الأقل، تحتوي حرفًا ورقمًا. الموظف مطالب بتغييرها عند أول دخول.</p>
        <p class="form-status is-error" data-form-error></p>
        <div class="btn-row"><button class="btn btn-primary" type="submit">حفظ</button><button class="btn btn-ghost" type="button" data-close-drawer>إلغاء</button></div>
      </form>`);
    $('#userForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const body = {};
      $$('[data-key]', e.target).forEach((el) => { if (el.value) body[el.dataset.key] = el.value; });
      try {
        if (user) await api(`/api/admin/users/${user.id}`, { method: 'PATCH', body: JSON.stringify(body) });
        else await api('/api/admin/users', { method: 'POST', body: JSON.stringify(body) });
        closeDrawer(); toast('تم الحفظ'); renderUsers();
      } catch (err) { $('[data-form-error]').textContent = err.message; }
    });
  }

  async function renderSettings() {
    const data = await api('/api/admin/settings');
    const s = data.settings;
    $('#view').innerHTML = `
      <div class="split">
        <div class="admin-card"><div class="admin-card-head"><h2>إعدادات الموقع</h2></div><div class="admin-card-body">
          <form id="settingsForm" class="stack">
            ${[['brand', 'اسم الشركة'], ['brandShort', 'الاسم المختصر'], ['whatsapp', 'رقم واتساب (دولي بدون +)'], ['heroHeadline', 'عنوان الواجهة'], ['heroSub', 'وصف الواجهة']]
              .map(([k, l]) => `<div class="field"><label>${l}</label><input data-key="${k}" value="${esc(s[k] || '')}" ${k === 'whatsapp' ? 'dir="ltr"' : ''}></div>`).join('')}
            <div class="field"><label>تنبيه التأشيرات</label><textarea data-key="visaDisclaimer" rows="3">${esc(s.visaDisclaimer || '')}</textarea></div>
            <div class="field"><label>ملاحظة المراجعات</label><textarea data-key="ratingNote" rows="2">${esc(s.ratingNote || '')}</textarea></div>
            <div class="field"><label>آخر تحديث للمحتوى</label><input data-key="lastContentUpdate" type="date" value="${esc(s.lastContentUpdate || '')}"></div>
            <button class="btn btn-primary" type="submit">حفظ الإعدادات</button>
            <p class="form-status" data-settings-status></p>
          </form>
        </div></div>
        <div class="admin-card"><div class="admin-card-head"><h2>كلمة المرور</h2></div><div class="admin-card-body">
          <form id="passwordForm" class="stack">
            <div class="field"><label>كلمة المرور الحالية</label><input data-key="currentPassword" type="password" dir="ltr" autocomplete="current-password"></div>
            <div class="field"><label>كلمة المرور الجديدة</label><input data-key="newPassword" type="password" dir="ltr" autocomplete="new-password"></div>
            <p class="field-hint">10 أحرف على الأقل، حرف ورقم. ستُنهى الجلسات الحالية بعد التغيير.</p>
            <button class="btn btn-primary" type="submit">تغيير كلمة المرور</button>
            <p class="form-status" data-password-status></p>
          </form>
        </div></div>
      </div>`;
    $('#settingsForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const body = {};
      $$('[data-key]', e.target).forEach((el) => { body[el.dataset.key] = el.value; });
      try {
        await api('/api/admin/settings', { method: 'PATCH', body: JSON.stringify(body) });
        $('[data-settings-status]').textContent = 'تم الحفظ';
        toast('تم حفظ الإعدادات');
      } catch (err) { $('[data-settings-status]').textContent = err.message; }
    });
    $('#passwordForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const body = {};
      $$('[data-key]', e.target).forEach((el) => { body[el.dataset.key] = el.value; });
      try {
        await api('/api/auth/change-password', { method: 'POST', body: JSON.stringify(body) });
        toast('تم تغيير كلمة المرور، سجّل الدخول من جديد');
        state.user = null;
        renderLogin('تم تغيير كلمة المرور. سجّل الدخول بكلمة المرور الجديدة.');
      } catch (err) { $('[data-password-status]').textContent = err.message; }
    });
  }

  async function renderAudit() {
    const data = await api('/api/admin/audit');
    $('#view').innerHTML = `<div class="admin-card"><div class="admin-card-body" style="padding:0">
      <table class="admin-table"><thead><tr><th>الوقت</th><th>المستخدم</th><th>الإجراء</th><th>العنصر</th><th>IP</th></tr></thead>
      <tbody>${data.entries.map((e) => `<tr><td>${dt(e.created_at)}</td><td>${esc(e.user_name || '—')}</td><td>${esc(e.action)}</td><td>${esc(e.entity || '')} ${esc(e.entity_id || '')}</td><td dir="ltr">${esc(e.ip || '')}</td></tr>`).join('') || '<tr><td colspan="5" class="muted">لا سجلات</td></tr>'}</tbody></table>
    </div></div>`;
  }

  async function renderAssistant() {
    const data = await api('/api/admin/assistant-log');
    $('#view').innerHTML = `<div class="admin-card"><div class="admin-card-head"><h2>جلسات المساعد</h2><span class="spacer" style="flex:1"></span><span class="muted" style="font-size:12px">تُسجَّل فقط بموافقة العميل</span></div>
      <div class="admin-card-body" style="padding:0">
        <table class="admin-table"><thead><tr><th>الجلسة</th><th>الموافقة</th><th>عدد الرسائل</th><th>آخر نشاط</th></tr></thead>
        <tbody>${data.sessions.map((s) => `<tr><td class="ref">${esc(s.sid.slice(0, 10))}…</td><td>${s.consent ? '✓' : '✕'}</td><td>${num(s.messages)}</td><td>${dt(s.last_at)}</td></tr>`).join('') || '<tr><td colspan="4" class="muted">لا جلسات محفوظة</td></tr>'}</tbody></table>
      </div></div>`;
  }

  /* ---------------- drawer ---------------- */
  function openDrawer(html) {
    closeDrawer();
    const wrap = document.createElement('div');
    wrap.className = 'drawer-backdrop';
    wrap.innerHTML = `<div class="drawer" role="dialog" aria-modal="true">${html}</div>`;
    document.body.append(wrap);
    state.overlay = wrap;
    wrap.addEventListener('click', (e) => {
      if (e.target === wrap || e.target.closest('[data-close-drawer]')) closeDrawer();
    });
    document.addEventListener('keydown', escClose);
  }

  function escClose(e) {
    if (e.key === 'Escape') closeDrawer();
  }

  function closeDrawer() {
    if (state.overlay) {
      state.overlay.remove();
      state.overlay = null;
      document.removeEventListener('keydown', escClose);
    }
  }

  /* ---------------- boot ---------------- */
  async function boot() {
    try {
      const me = await api('/api/auth/me');
      if (!me.user) return renderLogin();
      state.user = me.user;
      renderShell();
    } catch {
      renderLogin('تعذر الاتصال بالخادم.');
    }
  }

  boot();
})();
