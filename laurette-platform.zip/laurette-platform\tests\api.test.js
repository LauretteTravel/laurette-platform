import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import { rmSync, readFileSync } from 'node:fs';
import { randomBytes } from 'node:crypto';
import { createApp } from '../server.js';

const DB = `data/test-${randomBytes(4).toString('hex')}.db`;
let app;
let base;
let adminUser;
let adminPass;

const seed = JSON.parse(readFileSync('data/seed.json', 'utf8'));
adminUser = seed.users[0].username;
adminPass = seed.users[0].password;

let adminCookie = '';
let agentCookie = '';

async function call(path, { method = 'GET', body, cookie, headers = {}, origin } = {}) {
  const res = await fetch(`${base}${path}`, {
    method,
    headers: {
      ...(body ? { 'content-type': 'application/json' } : {}),
      ...(method !== 'GET' ? { 'x-requested-with': 'fetch' } : {}),
      ...(cookie ? { cookie } : {}),
      ...(origin ? { origin } : {}),
      ...headers,
    },
    body: body ? JSON.stringify(body) : undefined,
    redirect: 'manual',
  });
  const type = res.headers.get('content-type') || '';
  const payload = type.includes('json') ? await res.json() : await res.text();
  return { res, payload, type };
}

const login = async (username, password) => {
  const { res, payload } = await call('/api/auth/login', { method: 'POST', body: { username, password } });
  return { res, payload, cookie: (res.headers.get('set-cookie') || '').split(';')[0] };
};

before(async () => {
  for (const suffix of ['', '-wal', '-shm']) {
    try { rmSync(DB + suffix); } catch { /* ignore */ }
  }
  app = createApp({ dbFile: DB, baseUrl: 'http://127.0.0.1:0' });
  const addr = await app.listen(0, '127.0.0.1');
  base = `http://127.0.0.1:${addr.port}`;
});

after(async () => {
  await app.close();
  for (const suffix of ['', '-wal', '-shm']) {
    try { rmSync(DB + suffix); } catch { /* ignore */ }
  }
});

/* ---------------- pages & SEO ---------------- */

test('الصفحة الرئيسية تُعرض مع بيانات SEO منظّمة', async () => {
  const { res, payload } = await call('/');
  assert.equal(res.status, 200);
  assert.match(payload, /العالم بين يديك/);
  assert.match(payload, /<link rel="canonical"/);
  assert.match(payload, /application\/ld\+json/);
  assert.match(payload, /TravelAgency/);
  assert.match(payload, /name="description"/);
  const csp = res.headers.get('content-security-policy');
  assert.ok(csp, 'CSP header missing');
  assert.match(csp, /script-src 'self' 'nonce-/);
  assert.equal(res.headers.get('x-content-type-options'), 'nosniff');
});

test('صفحات عامة أساسية تعمل وترجع 200', async () => {
  for (const path of ['/programs', '/offers', '/programs/umrah-p1', '/umrah', '/flights', '/hotels', '/visa', '/consult', '/destinations', '/destinations/mecca', '/guide', '/faq', '/track', '/about', '/privacy', '/news', '/admin']) {
    const { res } = await call(path);
    assert.equal(res.status, 200, `فشل ${path}`);
  }
  const missing = await call('/programs/does-not-exist');
  assert.equal(missing.res.status, 404);
});

test('كل صفحة لها عنوان ووصف وكانونيكال مستقل', async () => {
  const titles = new Map();
  for (const path of ['/', '/programs', '/umrah', '/faq', '/guide', '/visa']) {
    const { payload } = await call(path);
    const title = (payload.match(/<title>([^<]+)<\/title>/) || [])[1];
    const desc = (payload.match(/<meta name="description" content="([^"]*)"/) || [])[1];
    const canonical = (payload.match(/<link rel="canonical" href="([^"]+)"/) || [])[1];
    assert.ok(title && desc && canonical, `${path} ينقصه meta`);
    assert.ok(!titles.has(title), `عنوان مكرر: ${title}`);
    titles.set(title, path);
  }
});

test('sitemap و robots و خريطة الموقع تعرض الروابط الصحيحة', async () => {
  const sitemap = await call('/sitemap.xml');
  assert.equal(sitemap.res.status, 200);
  assert.match(sitemap.payload, /\/programs\/umrah-p1/);
  assert.match(sitemap.payload, /urlset/);
  const robots = await call('/robots.txt');
  assert.match(robots.payload, /Disallow: \/admin/);
  assert.match(robots.payload, /Sitemap:/);
});

test('صفحة العروض تعرض البوسترات السبعة عشر مع بيانات المعاينة', async () => {
  const { res, payload } = await call('/offers');
  assert.equal(res.status, 200);
  assert.equal((payload.match(/class="poster-card/g) || []).length, 17);
  assert.ok((payload.match(/data-offer-open="/g) || []).length >= 17);
  assert.match(payload, /id="offersData"/);
  assert.match(payload, /id="offerDialog"/);
  assert.match(payload, /\/media\/offers\/poster-trabzon-thumb\.jpg/);
  assert.match(payload, /369 د\.أ/);

  const data = JSON.parse(payload.match(/<script type="application\/json" id="offersData"[^>]*>([\s\S]*?)<\/script>/)[1]);
  assert.equal(data.length, 17);
  const trabzon = data.find((o) => o.slug === 'offer-trabzon');
  assert.equal(trabzon.price, 369);
  assert.equal(trabzon.days, 8);
  assert.ok(trabzon.includes.length >= 3);
  assert.ok(trabzon.image.endsWith('.jpg'));
});

test('نافذة واتساب الفروع تحمل أرقام الفرعين كما في الموقع السابق', async () => {
  const { payload } = await call('/offers');
  assert.match(payload, /id="waModal"/);
  for (const number of ['0791193888', '0790915827', '0791192888', '0789795888', '0782965441']) {
    assert.match(payload, new RegExp(number), `الرقم ${number} غير موجود`);
  }
  assert.match(payload, /اختر الفرع للتواصل عبر واتساب/);
  const groups = payload.match(/<div class="wa-groups">([\s\S]*?)<\/div>\s*<div class="wa-footer">/)[1];
  assert.ok(!/الإدارة/.test(groups), 'لا يجب عرض أرقام الإدارة في نافذة واتساب');
});

test('بوسترات العروض تُخدم كصور محسّنة وخفيفة', async () => {
  const thumb = await call('/media/offers/poster-trabzon-thumb.jpg');
  assert.equal(thumb.res.status, 200);
  assert.equal(thumb.res.headers.get('content-type'), 'image/jpeg');
  const full = await call('/media/offers/poster-trabzon.jpg');
  assert.equal(full.res.status, 200);
  assert.match(full.res.headers.get('cache-control'), /max-age=604800/);
  const unknown = await call('/media/offers/nope.jpg');
  assert.equal(unknown.res.status, 404);
});

test('الصفحة الرئيسية تعرض العروض بالبوسترات ونافذة الواتساب', async () => {
  const { payload } = await call('/');
  assert.ok((payload.match(/class="poster-card/g) || []).length >= 4);
  assert.match(payload, /id="waModal"/);
  assert.match(payload, /data-wa-number/);
});

test('رسوم SVG تُخدم كصور ولا تحتاج أصولاً خارجية', async () => {
  const { res, payload } = await call('/art/haram.svg?v=2');
  assert.equal(res.status, 200);
  assert.equal(res.headers.get('content-type').split(';')[0], 'image/svg+xml');
  assert.match(payload, /<svg/);
});

/* ---------------- public API & requests ---------------- */

test('واجهة البرامج تعيد البرامج المنشورة فقط', async () => {
  const { res, payload } = await call('/api/programs?category=umrah&limit=5');
  assert.equal(res.status, 200);
  assert.equal(payload.ok, true);
  assert.ok(payload.programs.length > 0);
  assert.ok(payload.programs.every((p) => p.category === 'umrah'));
  assert.ok(payload.programs.every((p) => !('terms' in p) || Array.isArray(p.terms)));
});

const flightBody = () => ({
  type: 'flight',
  tripType: 'return',
  origin: 'عمّان (AMM)',
  destination: 'إسطنبول (IST)',
  departDate: new Date(Date.now() + 14 * 86400000).toISOString().slice(0, 10),
  returnDate: new Date(Date.now() + 21 * 86400000).toISOString().slice(0, 10),
  adults: 2,
  children: 0,
  infants: 0,
  cabin: 'economy',
  baggage: 'standard',
  name: 'أحمد الاختبار',
  phone: '0790000001',
  email: 'ahmad@example.com',
  consent: true,
  notes: 'اختبار آلي',
});

test('إنشاء طلب طيران يعيد رقماً مرجعياً ويُحفظ في قاعدة البيانات', async () => {
  const body = flightBody();
  const { res, payload } = await call('/api/requests', { method: 'POST', body });
  assert.equal(res.status, 201);
  assert.equal(payload.ok, true);
  assert.match(payload.reference, /^LT-FL-[A-Z0-9]{6}$/);
  assert.match(payload.summary, /عمّان/);
  const row = app.db.prepare('SELECT * FROM requests WHERE reference = ?').get(payload.reference);
  assert.ok(row);
  assert.equal(row.type, 'flight');
  assert.equal(row.status, 'new');
  assert.equal(row.department, 'تذاكر الطيران');
  const customer = app.db.prepare('SELECT * FROM customers WHERE phone = ?').get('0790000001');
  assert.ok(customer);
});

test('التحقق يمنع الطلبات الناقصة ويعيد أخطاء الحقول', async () => {
  const { res, payload } = await call('/api/requests', { method: 'POST', body: { type: 'flight', name: 'أ', phone: '123', consent: true } });
  assert.equal(res.status, 422);
  assert.equal(payload.ok, false);
  assert.ok(payload.errors.phone);
  assert.ok(payload.errors.origin || payload.errors.destination || payload.errors.departDate);
  const count = app.db.prepare('SELECT COUNT(*) n FROM requests').get().n;
  assert.equal(count, 1, 'لا يجب حفظ طلب غير صالح');
});

test('الموافقة على الخصوصية إلزامية', async () => {
  const body = { ...flightBody(), consent: false, phone: '0790000002' };
  const { res, payload } = await call('/api/requests', { method: 'POST', body });
  assert.equal(res.status, 422);
  assert.ok(payload.errors.consent);
});

test('منع تكرار الإرسال غير المقصود بنفس البيانات', async () => {
  const body = { ...flightBody(), phone: '0790000051', destination: 'أنطاليا (AYT)', notes: 'اختبار التكرار' };
  const first = await call('/api/requests', { method: 'POST', body });
  const second = await call('/api/requests', { method: 'POST', body });
  assert.equal(first.res.status, 201);
  assert.equal(second.res.status, 200);
  assert.equal(second.payload.duplicate, true);
  assert.equal(second.payload.reference, first.payload.reference);
  const n = app.db.prepare("SELECT COUNT(*) n FROM requests WHERE type='flight' AND json_extract(payload,'$.phone')='0790000051'").get().n;
  assert.equal(n, 1);
});

test('تتبع الطلب يتطلب الرقم المرجعي والهاتف معاً', async () => {
  const created = await call('/api/requests', { method: 'POST', body: { ...flightBody(), phone: '0790000010', destination: 'دبي (DXB)' } });
  const ref = created.payload.reference;
  const good = await call('/api/track', { method: 'POST', body: { reference: ref, phone: '0790000010' } });
  assert.equal(good.res.status, 200);
  assert.equal(good.payload.request.status, 'new');
  assert.equal(good.payload.request.phoneLast4, '0010');
  const badPhone = await call('/api/track', { method: 'POST', body: { reference: ref, phone: '0799999999' } });
  assert.equal(badPhone.res.status, 404);
  const unknown = await call('/api/track', { method: 'POST', body: { reference: 'LT-FL-ZZZZZZ', phone: '0790000010' } });
  assert.equal(unknown.res.status, 404);
});

test('نماذج الفنادق والتأشيرات والاستشارات والعمرة تُحفظ بأنواعها', async () => {
  const today = new Date();
  const iso = (d) => new Date(today.getTime() + d * 86400000).toISOString().slice(0, 10);
  const cases = [
    { type: 'hotel', country: 'تركيا', city: 'إسطنبول', checkIn: iso(10), checkOut: iso(14), rooms: 2, adults: 2, children: 1, childAges: [6], stars: '4', mealPlan: 'breakfast', name: 'سارة الاختبار', phone: '0790000020', consent: true },
    { type: 'visa', nationality: 'أردني', residence: 'الأردن', destination: 'تركيا', visaType: 'tourist', purpose: 'tourism', travelDate: iso(30), applicants: 2, name: 'خالد الاختبار', phone: '0790000021', consent: true },
    { type: 'consult', topic: 'honeymoon', message: 'نرغب بشهر عسل في إسطنبول لمدة أسبوع بميزانية محدودة.', channel: 'whatsapp', name: 'لينا الاختبار', phone: '0790000022', consent: true },
    { type: 'umrah', programSlug: 'umrah-p1', adults: 2, children: 0, infants: 0, preferredDate: iso(40), roomType: 'double', name: 'عمر الاختبار', phone: '0790000023', consent: true },
  ];
  for (const body of cases) {
    const { res, payload } = await call('/api/requests', { method: 'POST', body });
    assert.equal(res.status, 201, `${body.type}: ${JSON.stringify(payload)}`);
    assert.match(payload.reference, new RegExp(`^LT-${{ hotel: 'HT', visa: 'VS', consult: 'CS', umrah: 'UM' }[body.type]}-`));
    const row = app.db.prepare('SELECT * FROM requests WHERE reference = ?').get(payload.reference);
    assert.equal(row.type, body.type);
  }
});

test('طلب برنامج غير موجود يُرفض', async () => {
  const { res } = await call('/api/requests', { method: 'POST', body: { type: 'program', programSlug: 'no-such-program', adults: 1, name: 'اختبار', phone: '0790000030', consent: true } });
  assert.equal(res.status, 422);
});

/* ---------------- auth ---------------- */

test('لوحة الإدارة محمية: بلا جلسة تُرفض', async () => {
  for (const [path, method] of [['/api/admin/overview', 'GET'], ['/api/admin/requests', 'GET'], ['/api/admin/programs', 'GET']]) {
    const { res } = await call(path, { method });
    assert.equal(res.status, 401, path);
  }
});

test('بيانات الدخول الخاطئة تُرفض ولا تكشف وجود المستخدم', async () => {
  const { res, payload } = await call('/api/auth/login', { method: 'POST', body: { username: adminUser, password: 'wrong-password' } });
  assert.equal(res.status, 401);
  assert.equal(payload.message, 'اسم المستخدم أو كلمة المرور غير صحيحة');
});

test('تسجيل دخول المدير يعيد جلسة httpOnly', async () => {
  const { res, payload, cookie } = await login(adminUser, adminPass);
  assert.equal(res.status, 200);
  assert.equal(payload.user.role, 'admin');
  assert.match(cookie, /^lt_session=/);
  const setCookie = res.headers.get('set-cookie');
  assert.match(setCookie, /HttpOnly/);
  assert.match(setCookie, /SameSite=Strict/);
  adminCookie = cookie;
  const me = await call('/api/auth/me', { cookie: adminCookie });
  assert.equal(me.payload.user.username, adminUser);
});

test('تغيير حالة الطلب يحترم مسار الحالات', async () => {
  const row = app.db.prepare("SELECT id FROM requests WHERE type='flight' ORDER BY id LIMIT 1").get();
  const invalid = await call(`/api/admin/requests/${row.id}`, { method: 'PATCH', cookie: adminCookie, body: { status: 'confirmed' } });
  assert.equal(invalid.res.status, 422);
  const valid = await call(`/api/admin/requests/${row.id}`, { method: 'PATCH', cookie: adminCookie, body: { status: 'reviewing' } });
  assert.equal(valid.res.status, 200);
  const check = app.db.prepare('SELECT status FROM requests WHERE id = ?').get(row.id);
  assert.equal(check.status, 'reviewing');
  const back = await call(`/api/admin/requests/${row.id}`, { method: 'PATCH', cookie: adminCookie, body: { status: 'new' } });
  assert.equal(back.res.status, 422);
});

test('عرض السعر والملاحظات تُسجَّل وتظهر للعميل في التتبع', async () => {
  const row = app.db.prepare("SELECT id, reference FROM requests WHERE type='flight' ORDER BY id LIMIT 1").get();
  const payload = JSON.parse(app.db.prepare('SELECT payload FROM requests WHERE id = ?').get(row.id).payload);
  const update = await call(`/api/admin/requests/${row.id}`, { method: 'PATCH', cookie: adminCookie, body: { quoteAmount: 850, quoteNote: 'شامل الأمتعة', note: 'تم التواصل مع العميل' } });
  assert.equal(update.res.status, 200);
  const track = await call('/api/track', { method: 'POST', body: { reference: row.reference, phone: payload.phone } });
  assert.equal(track.payload.request.quote.amount, 850);
  const events = app.db.prepare('SELECT kind, message FROM request_events WHERE request_id = ?').all(row.id);
  assert.ok(events.some((e) => e.kind === 'quote'));
  assert.ok(events.some((e) => e.kind === 'note'));
});

test('قيمة عرض سالبة تُرفض', async () => {
  const row = app.db.prepare('SELECT id FROM requests ORDER BY id LIMIT 1').get();
  const { res } = await call(`/api/admin/requests/${row.id}`, { method: 'PATCH', cookie: adminCookie, body: { quoteAmount: -5 } });
  assert.equal(res.status, 422);
});

test('الموظف يرى الطلبات ولا يستطيع إدارة البرامج أو المستخدمين', async () => {
  const created = await call('/api/admin/users', {
    method: 'POST', cookie: adminCookie,
    body: { username: 'agent1', name: 'موظف اختبار', role: 'agent', department: 'تذاكر الطيران', password: 'AgentPass123' },
  });
  assert.equal(created.res.status, 201);
  const session = await login('agent1', 'AgentPass123');
  assert.equal(session.res.status, 200);
  agentCookie = session.cookie;

  const list = await call('/api/admin/requests', { cookie: agentCookie });
  assert.equal(list.res.status, 200);
  assert.ok(list.payload.total >= 1);

  const program = await call('/api/admin/programs', { method: 'POST', cookie: agentCookie, body: { title: 'محاولة موظف', category: 'umrah' } });
  assert.equal(program.res.status, 403);

  const users = await call('/api/admin/users', { cookie: agentCookie });
  assert.equal(users.res.status, 403);
});

test('المدير ينشئ ويعدّل ويحذف برنامجاً', async () => {
  const created = await call('/api/admin/programs', {
    method: 'POST', cookie: adminCookie,
    body: {
      title: 'برنامج اختبار مؤقت', slug: 'test-temp-program', category: 'umrah', days: 5, nights: 4, priceFrom: 500,
      hotels: ['مكة المكرمة | فندق اختبار | 5 | 300 م'], itinerary: ['وصول', 'عمرة'], includes: ['طيران'], options: ['غرفة ثنائية | 520'],
    },
  });
  assert.equal(created.res.status, 201);
  const id = created.payload.id;
  const row = app.db.prepare('SELECT * FROM programs WHERE id = ?').get(id);
  assert.equal(row.status, 'published');
  assert.equal(JSON.parse(row.hotels)[0].name, 'فندق اختبار');

  const patched = await call(`/api/admin/programs/${id}`, { method: 'PATCH', cookie: adminCookie, body: { priceFrom: 480, status: 'draft' } });
  assert.equal(patched.res.status, 200);
  assert.equal(app.db.prepare('SELECT price_from FROM programs WHERE id = ?').get(id).price_from, 480);

  const del = await call(`/api/admin/programs/${id}`, { method: 'DELETE', cookie: adminCookie });
  assert.equal(del.res.status, 200);
  assert.equal(app.db.prepare('SELECT COUNT(*) n FROM programs WHERE id = ?').get(id).n, 0);
});

test('المحتوى المحقون يُهرَّب في HTML', async () => {
  const created = await call('/api/admin/programs', {
    method: 'POST', cookie: adminCookie,
    body: { title: '<script>alert(1)</script>', slug: 'xss-check', category: 'istanbul' },
  });
  assert.equal(created.res.status, 201);
  const page = await call('/programs/xss-check');
  assert.equal(page.res.status, 200);
  assert.ok(!page.payload.includes('<script>alert(1)</script>'), 'الحقن لم يُهرَّب');
  assert.match(page.payload, /&lt;script&gt;alert\(1\)&lt;\/script&gt;/);
});

test('حماية CSRF: طلب من أصل مختلف أو بلا ترويسة يُرفض', async () => {
  const blocked = await call('/api/requests', { method: 'POST', body: flightBody(), headers: { 'x-requested-with': '' }, origin: 'https://evil.example' });
  assert.equal(blocked.res.status, 403);
  const allowed = await call('/api/requests', { method: 'POST', body: { ...flightBody(), phone: '0790000040' }, origin: base });
  assert.equal(allowed.res.status, 201);
});

test('تحديث الإعدادات ينعكس على الموقع', async () => {
  const update = await call('/api/admin/settings', { method: 'PATCH', cookie: adminCookie, body: { heroHeadline: 'عنوان تجريبي للاختبار' } });
  assert.equal(update.res.status, 200);
  const home = await call('/');
  assert.match(home.payload, /لوريت/);
  const setting = app.db.prepare("SELECT value FROM settings WHERE key='heroHeadline'").get();
  assert.equal(JSON.parse(setting.value), 'عنوان تجريبي للاختبار');
});

/* ---------------- assistant ---------------- */

test('المساعد يجيب عن العمرة من البيانات المنشورة فقط', async () => {
  const { res, payload } = await call('/api/assistant', { method: 'POST', body: { message: 'بدي برنامج عمرة اقتصادي' } });
  assert.equal(res.status, 200);
  assert.equal(payload.intent, 'umrah');
  assert.match(payload.reply, /برامج العمرة/);
  const prices = [...payload.reply.matchAll(/([\d,]{3,})\s*د\.أ/g)].map((m) => Number(m[1].replace(/,/g, '')));
  assert.ok(prices.length > 0, 'يجب أن يعرض سعراً من البيانات');
  for (const price of prices) {
    const found = app.db.prepare("SELECT COUNT(*) n FROM programs WHERE price_from = ?").get(price).n;
    assert.ok(found > 0, `السعر ${price} ليس من بيانات البرامج`);
  }
});

test('المساعد يرفض ضمان التأشيرة ويذكر المصدر', async () => {
  const guarantee = await call('/api/assistant', { method: 'POST', body: { message: 'هل تضمنون الموافقة على تأشيرة تركيا؟' } });
  assert.match(guarantee.payload.reply, /لا يمكن لأي جهة ضمان/);

  const visa = await call('/api/assistant', { method: 'POST', body: { message: 'ما متطلبات تأشيرة السعودية للعمرة؟' } });
  assert.match(visa.payload.reply, /لا نضمن الموافقة/);
  assert.ok(visa.payload.sources.some((s) => /visa\.mofa\.gov\.sa|السعودية|مركز التأشيرات/.test(`${s.label} ${s.url}`)));
});

test('المساعد يحوّل الأسئلة غير الموثقة إلى موظف ولا يخترع أرقاماً', async () => {
  const flight = await call('/api/assistant', { method: 'POST', body: { message: 'كم سعر تذكرة طيران عمّان طوكيو الأسبوع القادم؟' } });
  assert.equal(flight.payload.intent, 'flight');
  assert.ok(!/\d{3,}\s*د\.أ/.test(flight.payload.reply), 'يجب ألا يذكر سعراً مخترعاً للتذاكر');

  const { payload } = await call('/api/assistant', { method: 'POST', body: { message: 'هل تستخرجون تصديق شهادة ميلاد للسفر؟' } });
  assert.equal(payload.escalate, true);
  assert.match(payload.reply, /لم أجد معلومة موثوقة/);
  assert.ok(!/\d{3,}\s*د\.أ/.test(payload.reply), 'يجب ألا يذكر سعراً مخترعاً');
});

test('المحادثة لا تُحفظ بلا موافقة، وتُحفظ مع الموافقة', async () => {
  const before = app.db.prepare('SELECT COUNT(*) n FROM assistant_sessions').get().n;
  const anonymous = await call('/api/assistant', { method: 'POST', body: { message: 'مرحبا', consent: false } });
  assert.equal(anonymous.payload.sessionId, null);
  assert.equal(app.db.prepare('SELECT COUNT(*) n FROM assistant_sessions').get().n, before);

  const consented = await call('/api/assistant', { method: 'POST', body: { message: 'مرحبا، أريد برامج تركيا', consent: true } });
  assert.ok(consented.payload.sessionId);
  const after = app.db.prepare('SELECT COUNT(*) n FROM assistant_sessions').get().n;
  assert.equal(after, before + 1);
  const messages = app.db.prepare('SELECT role FROM assistant_messages WHERE session_id = (SELECT id FROM assistant_sessions WHERE sid = ?)').all(consented.payload.sessionId);
  assert.equal(messages.length, 2);
});

/* ---------------- hardening ---------------- */

test('حدود المعدل تمنع الإغراق', async () => {
  app.limiter.reset();
  let limited = 0;
  for (let i = 0; i < 24; i++) {
    const { res } = await call('/api/requests', { method: 'POST', body: { ...flightBody(), phone: `07900001${String(i).padStart(2, '0')}`, destination: `مدينة-${i}` } });
    if (res.status === 429) limited += 1;
  }
  assert.ok(limited > 0, 'لم يتم تطبيق حد المعدل');
  app.limiter.reset();
});

test('قفل المحاولات بعد 5 كلمات مرور خاطئة', async () => {
  for (let i = 0; i < 5; i++) await login('ghost-user', 'bad-password');
  const sixth = await login('ghost-user', 'bad-password');
  assert.equal(sixth.res.status, 429);
});

test('رأس CSP ونوع المحتوى يمنعان التنفيذ العرضي', async () => {
  const { res } = await call('/api/programs');
  assert.match(res.headers.get('content-type'), /application\/json/);
  assert.equal(res.headers.get('x-frame-options'), 'DENY');
  const page = await call('/');
  assert.match(page.res.headers.get('permissions-policy') || '', /geolocation=\(\)/);
});

test('سجل العمليات يوثّق تغييرات الموظفين', async () => {
  const { payload } = await call('/api/admin/audit', { cookie: adminCookie });
  assert.equal(payload.ok, true);
  const actions = payload.entries.map((e) => e.action);
  assert.ok(actions.includes('login'));
  assert.ok(actions.some((a) => a.startsWith('update-request')));
});

test('إحصاءات لوحة القيادة متوافقة مع قاعدة البيانات', async () => {
  const { payload } = await call('/api/admin/overview', { cookie: adminCookie });
  const dbTotal = app.db.prepare('SELECT COUNT(*) n FROM requests').get().n;
  assert.equal(payload.stats.total, dbTotal);
  assert.ok(payload.stats.byType.flight >= 1);
  assert.ok(Array.isArray(payload.recent));
});
